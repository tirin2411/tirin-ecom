importScripts('https://st-a.cdp.asia/antsomiSDKsw.js');
